﻿Model:
Extensa 5220
Extensa 5620
Extensa 5620G
Extensa 5620Z
Extensa 5620ZG
TravelMate 5320
TravelMate 5720
TravelMate 5720G

Launch CLB-135.exe and then follow the program procedure to flash BIOS.